from flask import Flask, render_template, request, jsonify
from datetime import datetime
import random

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get', methods=['POST'])
def chatbot_response():
    user_msg = request.json['msg'].lower()

    if user_msg in ['hi', 'hello', 'hey']:
        bot_reply = "Hello! How can I help you today?"

    elif "your name" in user_msg:
        bot_reply = "I am ChatBotX, your Python assistant!"

    elif "how are you" in user_msg:
        bot_reply = "I'm great, thanks for asking! How about you?"

    elif "time" in user_msg:
        now = datetime.now().strftime("%H:%M:%S")
        bot_reply = f"The current time is {now}"

    elif "date" in user_msg:
        today = datetime.now().strftime("%Y-%m-%d")
        bot_reply = f"Today's date is {today}"

    elif "joke" in user_msg:
        jokes = [
            "Why don’t scientists trust atoms? Because they make up everything!",
            "Why do programmers prefer dark mode? Because light attracts bugs!",
            "I told my computer I needed a break, and it said 'No problem. I’ll go to sleep.'"
        ]
        bot_reply = random.choice(jokes)

    elif "bye" in user_msg or "exit" in user_msg:
        bot_reply = "Goodbye! Have a great day 😊"

    else:
        bot_reply = "Sorry, I didn't understand that. Can you rephrase?"

    return jsonify({'reply': bot_reply})

if __name__ == '__main__':
    app.run(debug=True)
